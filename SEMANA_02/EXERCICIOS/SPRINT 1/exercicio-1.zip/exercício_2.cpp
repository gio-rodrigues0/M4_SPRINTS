#include <iostream>
#include <string>

using namespace std;

int escolheComando(){
  int comando;
  cin >> comando;
  if (comando == 0) {
    return 0;
  } else if (comando == 1) {
    return 1;
  }
} 

int main(){
  cout << "Digite o comando (0 ou 1):";
	int cmd = escolheComando();
	cout << "Comando Recebido: " << cmd << endl;
  return 0;
}