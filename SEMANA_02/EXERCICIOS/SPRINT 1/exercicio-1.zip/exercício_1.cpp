#include <iostream>
#include <string>

using namespace std;

float converte(float num, float min, float max){
  float resultado = (num - min) / (max - min);
  return resultado;
}

int main(){
	cout << converte(100,100,400) << endl;
  //valor esperado: 0
  
	cout << converte(400,100,400) << endl;
  //valor esperado: 1
  
	cout << converte(250,100,400) << endl;
  //valor esperado: 0.5
  return 0;
}