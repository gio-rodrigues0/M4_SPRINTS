#include <iostream>
#include <string>

using namespace std;

int dirMaiorDist(int* Vetor){
  //string direcao;
  int numDirecao;
  int i = 0;
  int maiorDirecao = 0;
  for (Vetor[i]; i < 4; i++){
    if (Vetor[i] > maiorDirecao){
      maiorDirecao = Vetor[i];
      numDirecao = i;
    }
  }
  if (numDirecao == 0){
    cout << "Direita" << endl;
  } else if (numDirecao == 1){
    cout << "Esquerda" << endl;
  } else if (numDirecao == 2){
    cout << "Frente" << endl;
  } else if (numDirecao == 3){
    cout << "Trás" << endl;
  } 

  return maiorDirecao;
}

int maiorDist(int* Vetor){
  int i = 0;
  int maiorDirecao = 0;
  for (Vetor[i]; i < 4; i++){
    if (Vetor[i] > maiorDirecao){
      maiorDirecao = Vetor[i];
    }
  }
  return maiorDirecao;
}

int main(){
  
  // "Direita", "Esquerda", "Frente", "Tras"
  int posicoes [4] = {0, 20, 100, 50};
  
  dirMaiorDist(posicoes);
  //valor esperado: Frente

  cout << maiorDist(posicoes) << endl;
  //valor esperado: 100


  // "Direita", "Esquerda", "Frente", "Tras"
  int posicoes2 [4] = {95, 70, 80, 50};
  
  dirMaiorDist(posicoes2);
  //valor esperado: Direita

  cout << maiorDist(posicoes2) << endl;
  //valor esperado: 95


  // "Direita", "Esquerda", "Frente", "Tras"
  int posicoes3 [4] = {10, 0, 50, 60};
  
  dirMaiorDist(posicoes3);
  //valor esperado: Tras

  cout << maiorDist(posicoes3) << endl;
  //valor esperado: 60


  // "Direita", "Esquerda", "Frente", "Tras"
  int posicoes4 [4] = {54, 55, 30, 0};
  
  dirMaiorDist(posicoes4);
  //valor esperado: Esquerda

  cout << maiorDist(posicoes4) << endl;
  //valor esperado: 55
  return 0;
}