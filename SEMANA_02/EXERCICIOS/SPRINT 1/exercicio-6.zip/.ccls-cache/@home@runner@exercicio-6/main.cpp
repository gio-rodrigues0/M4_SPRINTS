#include <iostream>
#include <string>

using namespace std;

int andar(int* vetor) {
  int maiorDist = 0;
  int direcao;
  int i = 0;
  for (vetor[i]; i < 4; i++){
    if (vetor[i] > maiorDist){
      maiorDist = vetor[i];
      direcao = i;
    }
  } 
  if (direcao == 0) {
      vetor[0] = vetor[0] - 50;
      vetor[1] = vetor[1] + 50;
  } else if (direcao == 1) {
      vetor[1] = vetor[1] - 50;
      vetor[0] = vetor[0] + 50;
  } else if (direcao == 2) {
      vetor[2] = vetor[2] - 50;
      vetor[3] = vetor[3] + 50;
  } else if (direcao == 3) {
      vetor[3] = vetor[3] - 50;
      vetor[2] = vetor[2] + 50;
  }
  
  cout << "Digite 0 para continuar e 1 para parar:";
  int digito;
  cin >> digito;
  return digito;
}

int main(){
  int vetor[4] = {50, 300, 100, 50};
  
  int parar = 0;

  while(parar == 0){
    cout << vetor[0] << endl;
    cout << vetor[1] << endl;
    cout << vetor[2] << endl;
    cout << vetor[3] << endl;
    parar = andar(vetor);
  }
}