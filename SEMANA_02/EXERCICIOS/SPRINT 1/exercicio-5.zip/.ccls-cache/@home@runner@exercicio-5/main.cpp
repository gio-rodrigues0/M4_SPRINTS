#include <iostream>
#include <string>

using namespace std;

int continuar() { 
  cout << "Digite 1 para parar o mapeamento!" << endl; 
  int digito;
  cin >> digito;
  if (digito == 1){
    return 1;
  } else{
    return 0;
  }
}

int main() {
  int parar = 0;

  while (parar == 0) {
    parar = continuar();
  }
  // A função deve perguntar: "Digite 1 para parar o mapeamento!"
  // Se o usuário digitar 1, deve sair do loop while declarado acima
  // Em caso contrário, continua no loop acima e pergunta novamente

  return 1;
}